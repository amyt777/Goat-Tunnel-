import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/server.dart';

class ConfigService {
  final String configUrl;
  ConfigService(this.configUrl);

  Future<List<Server>> fetchServers() async {
    final res = await http.get(Uri.parse(configUrl));
    if (res.statusCode != 200) {
      throw Exception('Failed to load config: ${res.statusCode}');
    }
    final data = json.decode(utf8.decode(res.bodyBytes));
    final List list = data['servers'] ?? [];
    return list.map((e) => Server.fromJson(e)).toList();
  }
}
