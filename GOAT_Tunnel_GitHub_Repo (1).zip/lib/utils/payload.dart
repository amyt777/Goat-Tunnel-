import '../models/server.dart';

String buildPayload(String raw, Server s) {
  return (raw)
      .replaceAll('[host]', s.host)
      .replaceAll('[port]', s.port.toString())
      .replaceAll('[host_port]', '${s.host}:${s.port}')
      .replaceAll('[sni]', s.sni ?? '')
      .replaceAll('[uuid]', s.uuid ?? '')
      .replaceAll('[path]', s.path ?? '')
      .replaceAll('[protocol]', s.protocol.toUpperCase())
      .replaceAll('[crlf]', '\r\n');
}
