class Server {
  final String id;
  final String label;
  final String protocol;
  final String host;
  final int port;
  final String country;
  final String tag;
  final int currentUsers;
  final int cpuLoad;
  final String? sni;
  final String? hostHeader;
  final String? payload;
  final String? payloadEncode;
  final String? uuid;
  final String? network;
  final String? path;
  final String? username;
  final String? password;
  final String? security;

  Server({
    required this.id,
    required this.label,
    required this.protocol,
    required this.host,
    required this.port,
    required this.country,
    required this.tag,
    required this.currentUsers,
    required this.cpuLoad,
    this.sni,
    this.hostHeader,
    this.payload,
    this.payloadEncode,
    this.uuid,
    this.network,
    this.path,
    this.username,
    this.password,
    this.security,
  });

  factory Server.fromJson(Map<String, dynamic> j) => Server(
    id: j['id'] ?? '',
    label: j['label'] ?? '',
    protocol: j['protocol'] ?? '',
    host: j['host'] ?? '',
    port: (j['port'] ?? 0) as int,
    country: j['country'] ?? '',
    tag: j['tag'] ?? '',
    currentUsers: (j['current_users'] ?? 0) as int,
    cpuLoad: (j['cpu_load'] ?? 0) as int,
    sni: j['sni'],
    hostHeader: j['host_header'],
    payload: j['payload'],
    payloadEncode: j['payload_encode'],
    uuid: j['uuid'],
    network: j['network'],
    path: j['path'],
    username: j['username'],
    password: j['password'],
    security: j['security'],
  );
}
