import 'package:flutter/material.dart';
import '../models/server.dart';
import '../services/config_service.dart';

class AppState extends ChangeNotifier {
  final ConfigService config;
  AppState(this.config);

  List<Server> _servers = [];
  bool _loading = false;
  String _protocol = 'ssl';
  String? _sniFilter;
  Server? _selected;
  String _customPayload = '';

  List<Server> get servers => _servers;
  bool get loading => _loading;
  String get protocol => _protocol;
  String? get sniFilter => _sniFilter;
  Server? get selected => _selected;
  String get customPayload => _customPayload;

  Future<void> refresh() async {
    _loading = true; notifyListeners();
    try {
      _servers = await config.fetchServers();
    } finally {
      _loading = false; notifyListeners();
    }
  }

  void setProtocol(String p) { _protocol = p; _selected=null; notifyListeners(); }
  void setSni(String? sni) { _sniFilter = sni?.isEmpty == true ? null : sni; notifyListeners(); }
  void setSelected(Server? s) { _selected = s; notifyListeners(); }
  void setCustomPayload(String v) { _customPayload = v; notifyListeners(); }

  List<String> sniOptions() {
    final set = <String>{};
    for (final s in _servers) {
      if (s.protocol == _protocol && (s.sni ?? '').isNotEmpty) set.add(s.sni!);
    }
    final list = set.toList()..sort();
    return list;
  }

  List<Server> filteredServers() {
    return _servers.where((s) {
      if (s.protocol != _protocol) return false;
      if (_sniFilter != null && (_sniFilter!.isNotEmpty)) {
        return (s.sni ?? '') == _sniFilter;
      }
      return true;
    }).toList();
  }
}
