import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/app_state.dart';
import 'services/config_service.dart';
import 'pages/home_page.dart';

void main() {
  const configUrl = 'https://arman-vpn.rf.gd/admin_v4/export.php';
  runApp(GoatTunnelApp(configUrl: configUrl));
}

class GoatTunnelApp extends StatelessWidget {
  final String configUrl;
  const GoatTunnelApp({super.key, required this.configUrl});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppState(ConfigService(configUrl))..refresh()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'GOAT Tunnel',
        theme: ThemeData(
          brightness: Brightness.dark,
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF8B5CF6), brightness: Brightness.dark),
          useMaterial3: true,
        ),
        home: const HomePage(),
      ),
    );
  }
}
