# GOAT Tunnel — GitHub Build (Phone Only)

**No login required. App name: GOAT Tunnel.**

## Get APK (from phone)
1. Upload this repo to GitHub (as-is).
2. Go to **Actions** → **GOAT Tunnel — Android Build** → **Run workflow**.
3. Wait a few minutes → open the run → **Artifacts** → download **goat-tunnel-debug-apk**.
   - Install `app-debug.apk` on your phone.

## Optional: Play Store release (AAB + signed APK)
Add repo **Secrets**:
- `ANDROID_KEYSTORE_BASE64` → base64 of `goattunnel-key.jks`
- `KEY_PROPERTIES` → contents of `android/key.properties`

Re-run workflow → download **goat-tunnel-release-builds** (AAB + signed APK).

## Config
The app fetches servers from:
```
https://arman-vpn.rf.gd/admin_v4/export.php
```
