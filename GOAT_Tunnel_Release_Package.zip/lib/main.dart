import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'src/providers/app_state.dart';
import 'src/services/config_service.dart';
import 'src/pages/home_page.dart';

void main() {
  const configUrl = 'https://arman-vpn.rf.gd/admin_v4/export.php';
  runApp(GoatTunnelApp(configUrl: configUrl));
}

class GoatTunnelApp extends StatelessWidget {
  final String configUrl;
  const GoatTunnelApp({super.key, required this.configUrl});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppState(ConfigService(configUrl))..refresh()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'GOAT Tunnel',
        theme: ThemeData(
          brightness: Brightness.dark,
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF8B5CF6),
            brightness: Brightness.dark,
          ),
          useMaterial3: true,
          fontFamily: 'Roboto',
        ),
        home: const SplashScreen(),
      ),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  late final Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500));
    _scale = Tween(begin: 0.85, end: 1.05).animate(CurvedAnimation(parent: _c, curve: Curves.easeInOut));
    _c.repeat(reverse: true);
    Future.delayed(const Duration(seconds: 2), (){
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_)=>const HomePage()));
    });
  }
  @override
  void dispose() { _c.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context){
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [Color(0xFF0A0F1F), Color(0xFF150F2F)]
          )
        ),
        child: Center(
          child: ScaleTransition(
            scale: _scale,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Image.asset('assets/images/goat_logo_256.png', width: 110, height: 110),
                const SizedBox(height: 14),
                const Text('GOAT Tunnel', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                const Text('Fast • Secure • Customizable', style: TextStyle(color: Colors.white70)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
