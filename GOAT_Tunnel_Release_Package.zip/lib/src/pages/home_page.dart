import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';
import '../models/server.dart';
import '../utils/payload.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final filtered = state.filteredServers();
    return Scaffold(
      appBar: AppBar(
        title: const Text('GOAT Tunnel'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: state.refresh,
          )
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [Color(0xFF0A0F1F), Color(0xFF150F2F)]
          )
        ),
        child: ListView(
          padding: const EdgeInsets.all(12),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Protocol', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    DropdownButton<String>(
                      value: state.protocol,
                      isExpanded: true,
                      items: const [
                        DropdownMenuItem(value: 'ssl', child: Text('SSL / TLS')),
                        DropdownMenuItem(value: 'vmess', child: Text('V2Ray (VMess)')),
                        DropdownMenuItem(value: 'vless', child: Text('V2Ray (VLess)')),
                        DropdownMenuItem(value: 'http', child: Text('HTTP (Custom Payload)')),
                        DropdownMenuItem(value: 'trojan', child: Text('Trojan')),
                        DropdownMenuItem(value: 'proxy', child: Text('Proxy / Direct')),
                      ],
                      onChanged: (v){ if(v!=null) state.setProtocol(v); },
                    ),
                    const SizedBox(height: 8),
                    const Text('SNI Filter (optional)'),
                    const SizedBox(height: 6),
                    DropdownButton<String?>(
                      value: state.sniFilter,
                      isExpanded: true,
                      hint: const Text('— Any SNI —'),
                      items: [
                        const DropdownMenuItem(value: null, child: Text('— Any SNI —')),
                        ...state.sniOptions().map((sni)=>DropdownMenuItem(value: sni, child: Text(sni))).toList()
                      ],
                      onChanged: (v){ state.setSni(v); },
                    )
                  ],
                ),
              ),
            ),

            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Servers', style: TextStyle(fontWeight: FontWeight.bold)),
                        Text('Total: ${filtered.length}'),
                      ],
                    ),
                    const SizedBox(height: 8),
                    ...filtered.map((s) => _ServerTile(server: s)).toList(),
                  ],
                ),
              ),
            ),

            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Custom Payload', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    TextField(
                      maxLines: 6,
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: 'Tokens: [host] [port] [host_port] [sni] [uuid] [path] [protocol] [crlf]'
                      ),
                      onChanged: state.setCustomPayload,
                    ),
                    const SizedBox(height: 8),
                    if (state.selected != null) ...[
                      const Text('Preview'),
                      const SizedBox(height: 6),
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(border: Border.all(color: Colors.grey.shade700)),
                        child: Text(buildPayload(state.customPayload, state.selected!)),
                      )
                    ] else const Text('Select a server to preview payload.')
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Row(
            children: [
              Expanded(child: ElevatedButton(
                onPressed: state.selected == null ? null : (){
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Simulated connect to ${state.selected!.label} (${state.selected!.protocol.toUpperCase()})'))
                  );
                },
                child: const Text('Connect (Simulated)'),
              )),
            ],
          ),
        ),
      ),
    );
  }
}

class _ServerTile extends StatelessWidget {
  final Server server;
  const _ServerTile({required this.server});

  @override
  Widget build(BuildContext context) {
    final state = context.read<AppState>();
    final selected = state.selected?.id == server.id;
    return ListTile(
      title: Text(server.label),
      subtitle: Text('${server.protocol.toUpperCase()} • ${server.host}:${server.port} • ${server.country} • ${server.tag}'),
      trailing: selected ? const Icon(Icons.check_circle, color: Colors.green) : null,
      onTap: (){
        state.setSelected(server);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Selected ${server.label}')));
      },
    );
  }
}
