GOAT Tunnel — Release Guide (Flutter, Android)

1) Install Flutter SDK then run:
   flutter clean
   flutter pub get

2) Generate signing key (once):
   keytool -genkey -v -keystore goattunnel-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias goattunnel

3) Create android/key.properties with:
   storePassword=YOUR_PASSWORD
   keyPassword=YOUR_PASSWORD
   keyAlias=goattunnel
   storeFile=goattunnel-key.jks

4) Edit android/app/build.gradle to use key.properties (see comments inside).

5) Build release AAB (for Play Store):
   flutter build appbundle --release

   Output:
   build/app/outputs/bundle/release/app-release.aab

6) (Optional) Build APK for sideload:
   flutter build apk --release

7) Update Play Store listing:
   - App name: GOAT Tunnel
   - Short desc: Lightweight & secure multi-protocol VPN
   - Long desc: see PlayStoreTexts.txt
   - Privacy policy: host assets/policy/privacy_policy.html to your domain or GitHub Pages

Config URL is set to:
   https://arman-vpn.rf.gd/admin_v4/export.php
Update lib/main.dart to change later.
