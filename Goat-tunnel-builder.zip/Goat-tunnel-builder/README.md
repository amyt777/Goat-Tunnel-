# GOAT Tunnel Builder
Uploads your Flutter project ZIP (GOAT_Tunnel_Pro_Lite.zip) and builds an APK automatically on Render.

## Usage
1. Upload this repo to your GitHub account.
2. Add your `GOAT_Tunnel_Pro_Lite.zip` in the same folder.
3. Connect this repo to Render.com → New Web Service → Deploy.
4. Render builds the APK and logs the path: `/app/app-release.apk`
