GOAT Tunnel Pro — Lite (APNA-style + GOAT Design)
=================================================

What you get:
- APNA-style tabs: Home / Servers / Settings (GOAT modern glow UI)
- Real VPN via Android VpnService + tun2socks (proxy/http first)
- Settings: Core Downloader (paste URL), Activation Key (placeholder), Ads toggle (local + remote flags)
- Admin export format supports: servers[], ads_enabled, license_required, message

Admin JSON example:
{
  "ads_enabled": false,
  "license_required": false,
  "message": "Welcome to GOAT Tunnel Pro",
  "servers": [
    {"id":"1","label":"US-Proxy-1","protocol":"proxy","host":"1.2.3.4","port":1080,"country":"US","tag":"fast","current_users":3,"cpu_load":12},
    {"id":"2","label":"DE-HTTP-1","protocol":"http","host":"5.6.7.8","port":8080,"country":"DE","tag":"free","current_users":1,"cpu_load":8}
  ]
}

Build:
- Phone-only via GitHub Actions (debug) or Termux (flutter build apk --debug).
- For release signing, add secrets: ANDROID_KEYSTORE_BASE64, KEY_PROPERTIES.
