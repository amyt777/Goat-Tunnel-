package com.goattunnel.pro.lite

import android.content.Intent
import androidx.annotation.NonNull
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import com.goattunnel.pro.lite.vpn.GoatVpnService
import com.goattunnel.pro.lite.vpn.CoreForegroundService

class MainActivity: FlutterActivity() {
    private val CHANNEL = "goat/channel"

    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "startVpn" -> {
                    val args = call.argument<List<String>>("args")?.let { ArrayList(it) } ?: arrayListOf()
                    val intent = Intent(this, GoatVpnService::class.java).apply {
                        action = GoatVpnService.ACTION_START
                        putStringArrayListExtra(GoatVpnService.EXTRA_ARGS, args)
                    }
                    startService(intent)
                    result.success(true)
                }
                "stopVpn" -> {
                    val intent = Intent(this, GoatVpnService::class.java).apply {
                        action = GoatVpnService.ACTION_STOP
                    }
                    startService(intent)
                    result.success(true)
                }
                "prepareCore" -> {
                    val url = call.argument<String>("url") ?: ""
                    CoreForegroundService.enqueueDownload(this, url)
                    result.success(true)
                }
                else -> result.notImplemented()
            }
        }
    }
}
