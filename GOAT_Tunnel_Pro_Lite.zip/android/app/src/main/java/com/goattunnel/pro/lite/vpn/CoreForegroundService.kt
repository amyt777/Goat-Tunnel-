package com.goattunnel.pro.lite.vpn

import android.app.*
import android.content.*
import android.os.*
import android.util.Log
import androidx.core.app.NotificationCompat
import java.io.*
import java.net.URL

class CoreForegroundService : Service() {
    companion object {
        const val TAG = "GoatCoreService"
        const val CHANNEL_ID = "goat_vpn_core"
        const val EXTRA_ARGS = "ARGS"
        const val EXTRA_TUN_FD = "TUN_FD"
        const val EXTRA_DOWNLOAD_URL = "DLURL"

        fun enqueueDownload(ctx: Context, url: String) {
            val i = Intent(ctx, CoreForegroundService::class.java).apply {
                putExtra(EXTRA_DOWNLOAD_URL, url)
            }
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, CoreForegroundService::class.java))
        }
    }

    private var coreProcess: Process? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("GOAT Tunnel Pro")
            .setContentText("Preparing...")
            .setSmallIcon(android.R.drawable.presence_online)
            .setOngoing(true)
            .build()
        startForeground(1, notification)

        val dl = intent?.getStringExtra(EXTRA_DOWNLOAD_URL)
        if (!dl.isNullOrEmpty()) {
            Thread { downloadCore(dl) }.start()
            return START_NOT_STICKY
        }

        val args = intent?.getStringArrayListExtra(EXTRA_ARGS) ?: arrayListOf()
        val tunFd = intent?.getIntExtra(EXTRA_TUN_FD, -1) ?: -1
        runCore(args, tunFd)
        return START_STICKY
    }

    private fun downloadCore(url: String) {
        try {
            val bin = File(filesDir, "tun2socks")
            URL(url).openStream().use { input ->
                FileOutputStream(bin).use { out -> input.copyTo(out) }
            }
            bin.setExecutable(true)
            notifyMsg("Core downloaded")
        } catch (e: Exception) {
            notifyMsg("Download failed: ${e.message}")
        } finally { stopSelf() }
    }

    private fun notifyMsg(msg: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val n = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("GOAT Tunnel Pro")
            .setContentText(msg)
            .setSmallIcon(android.R.drawable.presence_online)
            .build()
        nm.notify(1, n)
    }

    private fun runCore(args: ArrayList<String>, tunFd: Int) {
        try {
            val bin = File(filesDir, "tun2socks")
            if (!bin.exists() || !bin.canExecute()) {
                notifyMsg("Core missing. Use Settings → Download Core.")
                stopSelf(); return
            }
            val cmd = ArrayList<String>()
            cmd.add(bin.absolutePath)
            for (a in args) cmd.add(a.replace("__TUNFD__", tunFd.toString()))
            val pb = ProcessBuilder(cmd).redirectErrorStream(true)
            coreProcess = pb.start()
        } catch (e: Exception) {
            notifyMsg("Run failed: ${e.message}")
            stopSelf()
        }
    }

    override fun onDestroy() {
        coreProcess?.destroy()
        coreProcess = null
        super.onDestroy()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(CHANNEL_ID, "GOAT Tunnel Core", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(ch)
        }
    }
}
