package com.goattunnel.pro.lite.vpn

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log

class GoatVpnService : VpnService() {

    companion object {
        const val TAG = "GoatVpnService"
        const val ACTION_START = "START_VPN"
        const val ACTION_STOP = "STOP_VPN"
        const val EXTRA_ARGS = "ARGS"
    }

    private var tunInterface: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val args = intent.getStringArrayListExtra(EXTRA_ARGS) ?: arrayListOf()
                startVpn(args)
            }
            ACTION_STOP -> stopVpn()
        }
        return START_STICKY
    }

    private fun startVpn(args: ArrayList<String>) {
        val builder = Builder()
            .setSession("GOAT Tunnel Pro")
            .addAddress("10.10.0.2", 24)
            .addDnsServer("1.1.1.1")
            .addDnsServer("8.8.8.8")
            .addRoute("0.0.0.0", 0)
        tunInterface = builder.establish()

        if (tunInterface == null) {
            Log.e(TAG, "Failed to establish TUN")
            stopSelf(); return
        }

        val coreIntent = Intent(this, CoreForegroundService::class.java).apply {
            putStringArrayListExtra(CoreForegroundService.EXTRA_ARGS, args)
            putExtra(CoreForegroundService.EXTRA_TUN_FD, tunInterface!!.fd)
        }
        startForegroundService(coreIntent)
    }

    private fun stopVpn() {
        CoreForegroundService.stop(this)
        tunInterface?.close()
        tunInterface = null
        stopSelf()
    }

    override fun onRevoke() {
        super.onRevoke()
        stopVpn()
    }
}
