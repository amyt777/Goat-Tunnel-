import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/server.dart';

class ConfigBundle {
  final List<Server> servers;
  final bool adsEnabled;
  final bool licenseRequired;
  final String message;
  ConfigBundle(this.servers, this.adsEnabled, this.licenseRequired, this.message);
}

class ConfigService {
  final String configUrl;
  ConfigService(this.configUrl);

  Future<ConfigBundle> fetchAll() async {
    final res = await http.get(Uri.parse(configUrl));
    if (res.statusCode != 200) {
      throw Exception('Failed to load config: ${res.statusCode}');
    }
    final data = json.decode(utf8.decode(res.bodyBytes));
    final List list = data['servers'] ?? [];
    final servers = list.map((e) => Server.fromJson(e)).toList().cast<Server>();
    final ads = data['ads_enabled'] == true;
    final license = data['license_required'] == true;
    final msg = (data['message'] ?? '').toString();
    return ConfigBundle(servers, ads, license, msg);
  }
}
