import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  static const _ch = MethodChannel('goat/channel');
  bool connecting=false;
  bool connected=false;

  Future<void> _connect(BuildContext context) async {
    final s = context.read<AppState>().selected;
    if (s == null) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Select a server'))); return; }

    final args = <String>[
      "--netif-ipaddr","10.10.0.2",
      "--netif-netmask","255.255.255.0",
      "--tunfd","__TUNFD__",
      "--loglevel","info",
    ];
    if (s.protocol == "proxy") {
      args.addAll(["--socks-server-addr","${s.host}:${s.port}"]);
    } else if (s.protocol == "http") {
      args.addAll(["--http-server-addr","${s.host}:${s.port}"]);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Use proxy/http for now')));
      return;
    }
    setState(()=>connecting=true);
    await _ch.invokeMethod("startVpn", {"args": args});
    setState((){connecting=false; connected=true;});
  }

  Future<void> _disconnect() async {
    await _ch.invokeMethod("stopVpn");
    setState(()=>connected=false);
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final s = state.selected;
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              child: ListTile(
                title: Text(s?.label ?? 'No server selected'),
                subtitle: Text(s==null? 'Pick a server from the Servers tab' : '${s.protocol.toUpperCase()} • ${s.host}:${s.port}'),
                trailing: const Icon(Icons.arrow_forward_ios, size: 16),
              ),
            ),
            const SizedBox(height:16),
            Expanded(
              child: Center(
                child: GestureDetector(
                  onTap: connecting? null : (connected? _disconnect : ()=>_connect(context)),
                  child: Container(
                    width: 200, height: 200,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(colors:[Color(0xFF0A0F1F), Color(0xFF1B0B3A)]),
                      boxShadow: [
                        BoxShadow(color: const Color(0xFF8B5CF6).withOpacity(0.6), blurRadius: 30, spreadRadius: 2)
                      ],
                    ),
                    child: Center(child: Text(
                      connected? "DISCONNECT" : (connecting? "..." : "CONNECT"),
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    )),
                  ),
                ),
              ),
            ),
            const SizedBox(height:16),
            Row(
              children: [
                Expanded(child: FilledButton(
                  onPressed: connecting? null : (connected? _disconnect : ()=>_connect(context)),
                  child: Text(connected? "Disconnect" : (connecting? "Connecting..." : "Connect")),
                ))
              ],
            )
          ],
        ),
      ),
    );
  }
}
