import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';
import '../models/server.dart';

class ServersPage extends StatelessWidget {
  const ServersPage({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final srv = state.filteredServers();
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                const Text("Protocol:"),
                const SizedBox(width:8),
                DropdownButton<String>(
                  value: state.protocol,
                  items: const [
                    DropdownMenuItem(value:"proxy", child: Text("SOCKS5/Proxy")),
                    DropdownMenuItem(value:"http", child: Text("HTTP CONNECT")),
                    DropdownMenuItem(value:"ssl", child: Text("SSL (next)")),
                    DropdownMenuItem(value:"tcp", child: Text("TCP (next)")),
                    DropdownMenuItem(value:"udp", child: Text("UDP (next)")),
                  ],
                  onChanged: (v){ if(v!=null) state.setProtocol(v); },
                ),
                const Spacer(),
                IconButton(onPressed: ()=> state.refresh(), icon: const Icon(Icons.refresh))
              ],
            ),
            const SizedBox(height:8),
            Expanded(
              child: Card(
                child: ListView(
                  children: srv.map((s)=> ListTile(
                    title: Text(s.label),
                    subtitle: Text('${s.host}:${s.port}'),
                    trailing: state.selected?.id==s.id? const Icon(Icons.check_circle, color: Colors.green):null,
                    onTap: ()=> state.setSelected(s),
                  )).toList(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
