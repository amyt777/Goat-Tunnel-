import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  static const _ch = MethodChannel('goat/channel');
  final _url = TextEditingController();
  final _key = TextEditingController();
  bool adsToggle = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final sp = await SharedPreferences.getInstance();
    _url.text = sp.getString("core_url") ?? "https://example.com/tun2socks-android-arm64";
    _key.text = sp.getString("activation_key") ?? "";
    adsToggle = sp.getBool("ads_enabled_local") ?? false;
    setState((){});
  }

  Future<void> _saveCore() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString("core_url", _url.text.trim());
    if (_url.text.trim().isNotEmpty) {
      await _ch.invokeMethod("prepareCore", {"url": _url.text.trim()});
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Downloading core...')));
    }
  }

  Future<void> _saveKey() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString("activation_key", _key.text.trim());
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Key saved (validation pending)')));
  }

  Future<void> _toggleAds(bool v) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setBool("ads_enabled_local", v);
    setState(()=> adsToggle = v);
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text("Remote flags: ads=${state.adsEnabled}, license_required=${state.licenseRequired}"),
          const SizedBox(height:16),
          const Text("Core Binary URL (tun2socks)"),
          const SizedBox(height:8),
          TextField(
            controller: _url,
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              hintText: "https://yourdomain/path/tun2socks"
            ),
          ),
          const SizedBox(height:8),
          FilledButton(onPressed: _saveCore, child: const Text("Download Core")),
          const Divider(height:32),
          const Text("Activation Key (will unlock premium servers later)"),
          const SizedBox(height:8),
          TextField(
            controller: _key,
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              hintText: "Enter key..."
            ),
          ),
          const SizedBox(height:8),
          FilledButton(onPressed: _saveKey, child: const Text("Save Key")),
          const Divider(height:32),
          SwitchListTile(
            value: adsToggle,
            onChanged: _toggleAds,
            title: const Text("Enable Ads (local toggle for testing)"),
            subtitle: const Text("Remote flag from admin can override this"),
          ),
        ],
      ),
    );
  }
}
