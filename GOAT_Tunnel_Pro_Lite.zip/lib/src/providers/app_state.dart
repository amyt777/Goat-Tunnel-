import 'package:flutter/material.dart';
import '../models/server.dart';
import '../services/config_service.dart';

class AppState extends ChangeNotifier {
  final ConfigService config;
  AppState(this.config);

  List<Server> _servers = [];
  bool _loading = false;
  String _protocol = 'proxy';
  Server? _selected;

  // Remote flags
  bool adsEnabled = false;
  bool licenseRequired = false;
  String remoteMessage = '';

  List<Server> get servers => _servers;
  bool get loading => _loading;
  String get protocol => _protocol;
  Server? get selected => _selected;

  Future<void> refresh() async {
    _loading = true; notifyListeners();
    try {
      final data = await config.fetchAll();
      _servers = data.servers;
      adsEnabled = data.adsEnabled;
      licenseRequired = data.licenseRequired;
      remoteMessage = data.message;
    } finally {
      _loading = false; notifyListeners();
    }
  }

  void setProtocol(String p) { _protocol = p; _selected=null; notifyListeners(); }
  void setSelected(Server? s) { _selected = s; notifyListeners(); }

  List<Server> filteredServers() {
    return _servers.where((s) => s.protocol == _protocol).toList();
  }
}
