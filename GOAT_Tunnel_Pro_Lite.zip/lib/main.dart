import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'src/providers/app_state.dart';
import 'src/services/config_service.dart';
import 'src/pages/home_page.dart';
import 'src/pages/servers_page.dart';
import 'src/pages/settings_page.dart';

void main() {
  const configUrl = 'https://arman-vpn.rf.gd/admin_v4/export.php';
  runApp(GoatProApp(configUrl: configUrl));
}

class GoatProApp extends StatelessWidget {
  final String configUrl;
  const GoatProApp({super.key, required this.configUrl});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppState(ConfigService(configUrl))..refresh()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'GOAT Tunnel Pro',
        theme: ThemeData(
          brightness: Brightness.dark,
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF8B5CF6), brightness: Brightness.dark),
          useMaterial3: true,
        ),
        home: const Root(),
      ),
    );
  }
}

class Root extends StatefulWidget {
  const Root({super.key});
  @override
  State<Root> createState() => _RootState();
}

class _RootState extends State<Root> {
  int idx = 0;
  @override
  Widget build(BuildContext context) {
    final pages = [const HomePage(), const ServersPage(), const SettingsPage()];
    return Scaffold(
      body: pages[idx],
      bottomNavigationBar: NavigationBar(
        selectedIndex: idx,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.shield_moon), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.dns), label: 'Servers'),
          NavigationDestination(icon: Icon(Icons.settings), label: 'Settings'),
        ],
        onDestinationSelected: (i)=> setState(()=> idx=i),
      ),
    );
  }
}
